// src/lib/i18n.ts
export type UiLang = "TH" | "EN";

// แปลงรหัสภาษา UI -> enum ที่ GraphQL ต้องการ
export const toLangFilter = (ui: UiLang) => ui as any; // "TH" | "EN"
