// ดึงรายการโพสต์ตามภาษา
const ARTICLES = /* GraphQL */ `
  query ARTICLES($lang: LanguageCodeFilterEnum!, $first: Int = 12) {
    posts(where: { language: $lang }, first: $first) {
      nodes {
        title
        slug
        excerpt
        featuredImage {
          node {
            altText
            sourceUrl
            mediaDetails { sizes { name sourceUrl } }
          }
        }
        language { code }
      }
    }
  }
`;
export default ARTICLES;
